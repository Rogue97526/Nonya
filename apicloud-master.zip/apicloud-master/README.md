# apicloud
APICloud+项目实验室
APICloud+项目实验室主要做针对第三方模块的案例演示及开源   

@流浪男   QQ：343757327

config.xml需要自己配置

1、百度地图完整演示及案例

2、融云即时通讯（好友单聊功能完成）

[演示案例](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=14956)


