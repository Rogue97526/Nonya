---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: brandonskerritt

---
### Problem:
_What exactly do you think is missing? How does it impact you? Are there any hacks that people use instead?_

### Solution:
_How could this problem be solved? What could be added? How could it be integrated into the current system?_
