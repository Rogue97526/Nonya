#!/bin/bash
#
# This script will prep supported
# ChromeOS devices for Kodi installation via
# LibreELEC or GalliumOS/Ubuntu
#
# Created by Mr.Chromebox <mrchromebox@gmail.com>
#
# May be freely distributed and modified as needed,
# as long as proper attribution is given.
#

echo "This script is no longer supported; instead please use the Firmware"
echo "Utility Script as per the instructions on MrChromebox.tech"
