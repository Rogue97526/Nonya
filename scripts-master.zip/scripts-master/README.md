Home of the ChromeOS Firmware Utility script and Kodi E-Z Setup script.

For home info, please visit https://mrchromebox.tech
