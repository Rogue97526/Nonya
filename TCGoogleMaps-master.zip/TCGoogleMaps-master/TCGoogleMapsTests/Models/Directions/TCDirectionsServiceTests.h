//
//  TCDirectionsServiceTest.h
//  TCGoogleMaps
//
//  Created by Lee Tze Cheun on 9/1/13.
//  Copyright (c) 2013 Lee Tze Cheun. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@class TCDirectionsParameters;

@interface TCDirectionsServiceTests : SenTestCase

@property (nonatomic, strong) TCDirectionsParameters *dummyParameters;

@end
