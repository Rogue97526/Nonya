//
//  TCDistanceTests.h
//  TCGoogleMaps
//
//  Created by Lee Tze Cheun on 8/31/13.
//  Copyright (c) 2013 Lee Tze Cheun. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TCDistanceTests : SenTestCase

@end
