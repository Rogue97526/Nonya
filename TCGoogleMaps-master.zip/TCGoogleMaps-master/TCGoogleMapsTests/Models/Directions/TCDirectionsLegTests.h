//
//  TCDirectionsLegTests.h
//  TCGoogleMaps
//
//  Created by Lee Tze Cheun on 9/3/13.
//  Copyright (c) 2013 Lee Tze Cheun. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TCDirectionsLegTests : SenTestCase

@end
