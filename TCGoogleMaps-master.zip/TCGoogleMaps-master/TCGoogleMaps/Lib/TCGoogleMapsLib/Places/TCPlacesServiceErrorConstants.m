//
//  TCPlacesServiceErrorConstants.m
//  TCGoogleMaps
//
//  Created by Lee Tze Cheun on 9/9/13.
//  Copyright (c) 2013 Lee Tze Cheun. All rights reserved.
//

#import "TCPlacesServiceErrorConstants.h"

NSString * const TCPlacesServiceErrorDomain = @"com.tclee.GoogleMaps.Places.TCPlacesServiceErrorDomain";
NSString * const TCPlacesServiceStatusCodeErrorKey = @"TCPlacesServiceStatusCode";
