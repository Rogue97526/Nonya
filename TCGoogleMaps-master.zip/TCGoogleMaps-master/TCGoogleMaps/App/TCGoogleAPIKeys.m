//
//  TCGoogleAPIKeys.m
//  TCGoogleMaps
//
//  Created by Lee Tze Cheun on 8/19/13.
//  Copyright (c) 2013 Lee Tze Cheun. All rights reserved.
//

#import "TCGoogleAPIKeys.h"

// Get your own API keys from http://code.google.com/apis/console‎
NSString * const kTCGoogleMapsAPIKey = @"AIzaSyD7bKmFkhRWKdAKkASeccZB3D4LrRj0yAY";
NSString * const kTCGooglePlacesAPIKey = @"AIzaSyBDNqerk86QTl8UV-lz2l5y1vga9OsItq8";
