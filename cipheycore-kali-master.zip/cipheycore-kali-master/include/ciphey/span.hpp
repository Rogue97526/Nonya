#pragma once
#define span_CONFIG_SELECT_SPAN span_SPAN_NONSTD
#define span_CONFIG_CONTRACT_VIOLATION_THROWS 1

#include <ciphey/span.hxx>
