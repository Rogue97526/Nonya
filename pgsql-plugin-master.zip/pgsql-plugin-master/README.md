pgsql-plugin
============

PGSQL Plugin is a Bacula File Daemon plugin wich perform PostgreSQL database on-line backup and point-in-time recovery.
