--drop schema
DROP SCHEMA IF EXISTS sch_chameleon CASCADE;
