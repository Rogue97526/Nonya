DELETE FROM test WHERE value1='the answer';
