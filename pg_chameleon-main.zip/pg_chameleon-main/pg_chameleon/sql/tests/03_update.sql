UPDATE test SET value2 = 'world' WHERE value1 = 'hello';
