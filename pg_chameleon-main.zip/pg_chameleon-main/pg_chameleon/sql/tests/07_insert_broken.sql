INSERT INTO test_broken (value1,value2,val_enum)
VALUES
('hello','dave','postgresql'),
('knock knock','neo','rocks'),
('the answer','is 42',NULL);
