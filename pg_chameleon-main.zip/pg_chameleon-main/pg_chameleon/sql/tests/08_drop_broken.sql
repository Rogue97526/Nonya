DROP TABLE test_broken ;
