INSERT INTO test (value1,value2,date_create,count,log,status)
VALUES
('the answer','is 42','0000-00-00',0,'foo',10);
