INSERT INTO test (value1,value2,date_create)
VALUES
('hello','dave',now()),
('knock knock','neo','2015-01-01'),
('the answer','is 42','0000-00-00');
