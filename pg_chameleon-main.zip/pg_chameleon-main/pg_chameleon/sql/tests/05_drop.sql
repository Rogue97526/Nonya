DROP TABLE test ;
