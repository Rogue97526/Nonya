global_lib api documentation
======================================================

.. automodule:: global_lib
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
