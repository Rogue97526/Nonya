# Private-Api-Snapchat-Hack-iOS---v1-Auth
This is forked <a href="https://github.com/unixpickle/SnapchatHax">SnapchatHax</a> with many changes with request signing,
snapchathax initially was working fine until beginning of 2015. Later
snapchat introduced  X-Snapchat-Client-Token and
X-Snapchat-Client-Auth-Token which made most 3-rd party apps killed.
After that i have reversed their ios app and created working method, i
have used this project only to testing, most changes has been made in
<a href="https://github.com/karek314/Private-Api-Snapchat-Hack-iOS---v1-Auth/blob/master/SnapchatHax/Snapchat/Internal/SCSigner.m">SCSigner</a> file. It was quite tricky to reverse this method. Currently
they have disabled v1, and introduced v2 which may take longer time to
reverse, currently i don't have time to reverse another version. This
project as it is do not work with snapchat, it's for educational
purposes how does Snapchat sign their request, it may help somone to
hack further methods v2,v3... :)

#License
The MIT License (MIT)
#Donate
Bitcoin -> 1MsCcLLzaZtgEiMsigFoRJjz149mPSoFKC<br>
![alt tag](http://s16.postimg.org/xbne92mdx/image.png)<br>

Ethereum -> 0x9284e52d64d888f2aa1bb62a38f3b5259487376a

