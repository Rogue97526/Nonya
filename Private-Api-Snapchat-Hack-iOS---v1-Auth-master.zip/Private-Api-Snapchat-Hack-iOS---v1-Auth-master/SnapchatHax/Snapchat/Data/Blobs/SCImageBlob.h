//
//  SCImageBlob.h
//  SnapchatHax
//
//  Created by Alex Nichol on 12/17/13.
//  Copyright (c) 2013 Alex Nichol. All rights reserved.
//

#import "SCBlob.h"

@interface SCImageBlob : SCBlob

@end
