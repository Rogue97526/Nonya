# FileRecoveryTool
A Forensics Mini Project - File Recovery Tool that extracts Images and PDF from the memory dump image
