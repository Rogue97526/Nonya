paper-spinner
=============

A material-design circular activity indicator.
