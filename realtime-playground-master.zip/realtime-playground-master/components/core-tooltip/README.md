core-tooltip
============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-tooltip) for more information.
