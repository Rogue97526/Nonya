core-icon-button
================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-icon-button) for more information.
